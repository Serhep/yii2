<?php

/* @var $this yii\web\View */

$this->title = 'Test Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Test Application</h1>

        
    </div>

</div>
