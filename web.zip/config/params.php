<?php

return [
    'adminEmail' => 'admin@test.com',
    'adminPassword' => '123456',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',

    'shopName' => 'Тест',
    /*
     * Значения по умолчанию для мета-тегов title, keywords и description
     */
    'defaultTitle' => 'Магазин',
    'defaultKeywords' => 'Магазин',
    'defaultDescription' => 'Магазин',
    /*
     * Количество товаров на странице для постраничной навигации
     */
    'pageSize' => 2
];
